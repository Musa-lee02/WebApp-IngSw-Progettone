--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ambito; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ambito (
    id_ambito bigint NOT NULL,
    nome character varying(50)
);


ALTER TABLE public.ambito OWNER TO postgres;

--
-- Name: annuncio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.annuncio (
    id_annuncio bigint NOT NULL,
    titolo character varying(50),
    descrizione text,
    data_di_scadenza date,
    provincia_annuncio character varying(50),
    img_annuncio text,
    username_cliente character varying(20),
    id_ambito bigint
);


ALTER TABLE public.annuncio OWNER TO postgres;

--
-- Name: chat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chat (
    id_annuncio bigint NOT NULL,
    username_cliente character varying(20) NOT NULL,
    username_lavoratore character varying(20) NOT NULL
);


ALTER TABLE public.chat OWNER TO postgres;

--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente (
    username character varying(20) NOT NULL
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- Name: competente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.competente (
    username_lavoratore character varying(20) NOT NULL,
    id_ambito bigint NOT NULL
);


ALTER TABLE public.competente OWNER TO postgres;

--
-- Name: db_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.db_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.db_sequence OWNER TO postgres;

--
-- Name: lavoratore; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lavoratore (
    username character varying(20) NOT NULL,
    provincia_lavoro character varying(50) NOT NULL,
    notifica_email boolean NOT NULL,
    punteggio integer
);


ALTER TABLE public.lavoratore OWNER TO postgres;

--
-- Name: messaggio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messaggio (
    id_messaggio bigint NOT NULL,
    contenuto text,
    data timestamp without time zone,
    visualizzato boolean,
    chi boolean,
    id_annuncio bigint,
    username_cliente character varying(20),
    username_lavoratore character varying(20)
);


ALTER TABLE public.messaggio OWNER TO postgres;

--
-- Name: notifica; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifica (
    id_notifica bigint NOT NULL,
    contenuto text,
    data timestamp without time zone,
    visualizzato boolean,
    chi boolean,
    username character varying(20)
);


ALTER TABLE public.notifica OWNER TO postgres;

--
-- Name: proposta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proposta (
    id_annuncio bigint NOT NULL,
    username_lavoratore character varying(20) NOT NULL,
    data_lavoro date,
    descrizione text,
    stato character varying(20),
    stato_lavoro character varying(20),
    prezzo_lavoro numeric
);


ALTER TABLE public.proposta OWNER TO postgres;

--
-- Name: recensione; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recensione (
    id_recensione bigint NOT NULL,
    titolo character varying(50),
    descrizione text,
    punteggio integer,
    username_cliente character varying(20),
    username_lavoratore character varying(20)
);


ALTER TABLE public.recensione OWNER TO postgres;

--
-- Name: transazione_pagamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transazione_pagamento (
    id_transazione_pagamento bigint NOT NULL,
    importo numeric,
    data timestamp without time zone,
    metodo_di_pagamento character varying(50),
    username_cliente character varying(20),
    username_lavoratore character varying(20)
);


ALTER TABLE public.transazione_pagamento OWNER TO postgres;

--
-- Name: utente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utente (
    username character varying(20) NOT NULL,
    password text NOT NULL,
    email character varying(100) NOT NULL,
    nome character varying(50) NOT NULL,
    cognome character varying(50) NOT NULL,
    provincia character varying(50) NOT NULL,
    img_profilo text NOT NULL,
    registrato boolean NOT NULL,
    data_registrazione date NOT NULL
);


ALTER TABLE public.utente OWNER TO postgres;

--
-- Data for Name: ambito; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ambito (id_ambito, nome) FROM stdin;
\.
COPY public.ambito (id_ambito, nome) FROM '$$PATH$$/4866.dat';

--
-- Data for Name: annuncio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.annuncio (id_annuncio, titolo, descrizione, data_di_scadenza, provincia_annuncio, img_annuncio, username_cliente, id_ambito) FROM stdin;
\.
COPY public.annuncio (id_annuncio, titolo, descrizione, data_di_scadenza, provincia_annuncio, img_annuncio, username_cliente, id_ambito) FROM '$$PATH$$/4868.dat';

--
-- Data for Name: chat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chat (id_annuncio, username_cliente, username_lavoratore) FROM stdin;
\.
COPY public.chat (id_annuncio, username_cliente, username_lavoratore) FROM '$$PATH$$/4870.dat';

--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cliente (username) FROM stdin;
\.
COPY public.cliente (username) FROM '$$PATH$$/4865.dat';

--
-- Data for Name: competente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.competente (username_lavoratore, id_ambito) FROM stdin;
\.
COPY public.competente (username_lavoratore, id_ambito) FROM '$$PATH$$/4867.dat';

--
-- Data for Name: lavoratore; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lavoratore (username, provincia_lavoro, notifica_email, punteggio) FROM stdin;
\.
COPY public.lavoratore (username, provincia_lavoro, notifica_email, punteggio) FROM '$$PATH$$/4864.dat';

--
-- Data for Name: messaggio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messaggio (id_messaggio, contenuto, data, visualizzato, chi, id_annuncio, username_cliente, username_lavoratore) FROM stdin;
\.
COPY public.messaggio (id_messaggio, contenuto, data, visualizzato, chi, id_annuncio, username_cliente, username_lavoratore) FROM '$$PATH$$/4871.dat';

--
-- Data for Name: notifica; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifica (id_notifica, contenuto, data, visualizzato, chi, username) FROM stdin;
\.
COPY public.notifica (id_notifica, contenuto, data, visualizzato, chi, username) FROM '$$PATH$$/4872.dat';

--
-- Data for Name: proposta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.proposta (id_annuncio, username_lavoratore, data_lavoro, descrizione, stato, stato_lavoro, prezzo_lavoro) FROM stdin;
\.
COPY public.proposta (id_annuncio, username_lavoratore, data_lavoro, descrizione, stato, stato_lavoro, prezzo_lavoro) FROM '$$PATH$$/4869.dat';

--
-- Data for Name: recensione; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recensione (id_recensione, titolo, descrizione, punteggio, username_cliente, username_lavoratore) FROM stdin;
\.
COPY public.recensione (id_recensione, titolo, descrizione, punteggio, username_cliente, username_lavoratore) FROM '$$PATH$$/4873.dat';

--
-- Data for Name: transazione_pagamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transazione_pagamento (id_transazione_pagamento, importo, data, metodo_di_pagamento, username_cliente, username_lavoratore) FROM stdin;
\.
COPY public.transazione_pagamento (id_transazione_pagamento, importo, data, metodo_di_pagamento, username_cliente, username_lavoratore) FROM '$$PATH$$/4874.dat';

--
-- Data for Name: utente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.utente (username, password, email, nome, cognome, provincia, img_profilo, registrato, data_registrazione) FROM stdin;
\.
COPY public.utente (username, password, email, nome, cognome, provincia, img_profilo, registrato, data_registrazione) FROM '$$PATH$$/4863.dat';

--
-- Name: db_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.db_sequence', 863, true);


--
-- Name: ambito ambito_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ambito
    ADD CONSTRAINT ambito_pkey PRIMARY KEY (id_ambito);


--
-- Name: annuncio annuncio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annuncio
    ADD CONSTRAINT annuncio_pkey PRIMARY KEY (id_annuncio);


--
-- Name: chat chat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_pkey PRIMARY KEY (id_annuncio, username_cliente, username_lavoratore);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (username);


--
-- Name: competente competente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competente
    ADD CONSTRAINT competente_pkey PRIMARY KEY (username_lavoratore, id_ambito);


--
-- Name: lavoratore lavoratore_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lavoratore
    ADD CONSTRAINT lavoratore_pkey PRIMARY KEY (username);


--
-- Name: messaggio messaggio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messaggio
    ADD CONSTRAINT messaggio_pkey PRIMARY KEY (id_messaggio);


--
-- Name: notifica notifica_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifica
    ADD CONSTRAINT notifica_pkey PRIMARY KEY (id_notifica);


--
-- Name: proposta proposta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proposta
    ADD CONSTRAINT proposta_pkey PRIMARY KEY (id_annuncio, username_lavoratore);


--
-- Name: recensione recensione_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_pkey PRIMARY KEY (id_recensione);


--
-- Name: transazione_pagamento transazione_pagamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transazione_pagamento
    ADD CONSTRAINT transazione_pagamento_pkey PRIMARY KEY (id_transazione_pagamento);


--
-- Name: utente utente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utente
    ADD CONSTRAINT utente_pkey PRIMARY KEY (username);


--
-- Name: annuncio annuncio_id_ambito_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annuncio
    ADD CONSTRAINT annuncio_id_ambito_fkey FOREIGN KEY (id_ambito) REFERENCES public.ambito(id_ambito);


--
-- Name: annuncio annuncio_username_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annuncio
    ADD CONSTRAINT annuncio_username_cliente_fkey FOREIGN KEY (username_cliente) REFERENCES public.cliente(username);


--
-- Name: chat chat_id_annuncio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_id_annuncio_fkey FOREIGN KEY (id_annuncio) REFERENCES public.annuncio(id_annuncio);


--
-- Name: chat chat_username_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_username_cliente_fkey FOREIGN KEY (username_cliente) REFERENCES public.cliente(username);


--
-- Name: chat chat_username_lavoratore_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_username_lavoratore_fkey FOREIGN KEY (username_lavoratore) REFERENCES public.lavoratore(username);


--
-- Name: cliente cliente_username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_username_fkey FOREIGN KEY (username) REFERENCES public.utente(username);


--
-- Name: competente competente_id_ambito_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competente
    ADD CONSTRAINT competente_id_ambito_fkey FOREIGN KEY (id_ambito) REFERENCES public.ambito(id_ambito);


--
-- Name: competente competente_username_lavoratore_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competente
    ADD CONSTRAINT competente_username_lavoratore_fkey FOREIGN KEY (username_lavoratore) REFERENCES public.lavoratore(username);


--
-- Name: lavoratore lavoratore_username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lavoratore
    ADD CONSTRAINT lavoratore_username_fkey FOREIGN KEY (username) REFERENCES public.utente(username);


--
-- Name: messaggio messaggio_id_annuncio_username_cliente_username_lavoratore_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messaggio
    ADD CONSTRAINT messaggio_id_annuncio_username_cliente_username_lavoratore_fkey FOREIGN KEY (id_annuncio, username_cliente, username_lavoratore) REFERENCES public.chat(id_annuncio, username_cliente, username_lavoratore);


--
-- Name: notifica notifica_username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifica
    ADD CONSTRAINT notifica_username_fkey FOREIGN KEY (username) REFERENCES public.utente(username);


--
-- Name: proposta proposta_id_annuncio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proposta
    ADD CONSTRAINT proposta_id_annuncio_fkey FOREIGN KEY (id_annuncio) REFERENCES public.annuncio(id_annuncio);


--
-- Name: proposta proposta_username_lavoratore_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proposta
    ADD CONSTRAINT proposta_username_lavoratore_fkey FOREIGN KEY (username_lavoratore) REFERENCES public.lavoratore(username);


--
-- Name: recensione recensione_username_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_username_cliente_fkey FOREIGN KEY (username_cliente) REFERENCES public.cliente(username);


--
-- Name: recensione recensione_username_lavoratore_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_username_lavoratore_fkey FOREIGN KEY (username_lavoratore) REFERENCES public.lavoratore(username);


--
-- Name: transazione_pagamento transazione_pagamento_username_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transazione_pagamento
    ADD CONSTRAINT transazione_pagamento_username_cliente_fkey FOREIGN KEY (username_cliente) REFERENCES public.cliente(username);


--
-- Name: transazione_pagamento transazione_pagamento_username_lavoratore_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transazione_pagamento
    ADD CONSTRAINT transazione_pagamento_username_lavoratore_fkey FOREIGN KEY (username_lavoratore) REFERENCES public.lavoratore(username);


--
-- PostgreSQL database dump complete
--

